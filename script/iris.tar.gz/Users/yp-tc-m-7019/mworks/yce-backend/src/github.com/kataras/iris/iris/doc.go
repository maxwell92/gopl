package main // import "github.com/kataras/iris/iris"

/*

go get -u github.com/kataras/iris/iris


// create command
create an empty folder, open the command prompt/terminal there, type and press enter:

iris create


// run command
navigate to your app's directory and execute:

iris run main.go
*/
