## Package information

This package contains helpful functions that iris, internally, uses


**That's it.**
