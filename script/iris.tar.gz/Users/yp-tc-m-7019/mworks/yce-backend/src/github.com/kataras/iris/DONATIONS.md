
I spend all my time in the construction of Iris, therefore I have no income value.

If you,

- think that any information you obtained here is worth some money
- believe that Iris worths to remains a highly active project

Feel free to send **any** amount through paypal

[![](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=makis%40ideopod%2ecom&lc=GR&item_name=Iris%20web%20framework&item_number=iriswebframeworkdonationid2016&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted&&return=http://iris-go.com/assets/v4-book/iris.pdf&cancel_return=https://www.gitbook.com/book/kataras/iris/details)

Benefits:

- Direct download the `donator edition guide`
- Access to the 'donors' [private chat room](https://kataras.rocket.chat/group/donors), real-time assistance by me.

**Thank you**!

### More about your donations


I'm  grateful for all the generous donations. Iris is fully funded by these donations.

#### Donors

- [Ryan Brooks](https://github.com/ryanbyyc) donated 50 EUR at May 11

> The name of the donator added after his/her permission.

#### Report, so far

- 13 EUR for the domain, [iris-go.com](https://iris-go.com)


**Available**: VAT(50)-13 = 47.5-13 = 34.5 EUR
