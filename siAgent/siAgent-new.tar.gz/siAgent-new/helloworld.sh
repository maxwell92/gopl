#! /bin/bash

SLEEPTIME=$((RANDOM % 20 + 1))
echo Hello $1,$2 
sleep $SLEEPTIME 
echo sleep $SLEEPTIME
exit 0
